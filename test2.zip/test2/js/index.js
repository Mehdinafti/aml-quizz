// ══ Constants ════════════════════════════════════════════
const SAVE_KEY       = 'aml_quiz_progress';
const SESSION_SIZE   = 120;
const PASS_THRESHOLD = 75;

// ══ State ════════════════════════════════════════════════
let allQuestions   = [];
let sessions       = [];
let sessionIdx     = 0;
let questions      = [];
let currentIdx     = 0;
let answers        = {};
let flagged        = {};
let savedProgress  = null;
let isRetryMode    = false;
let sessionHistory = [];  // [{ correct, total, elapsed }, ...]

// Timer
let elapsedSeconds = 0;
let timerInterval  = null;
let isPaused       = false;

// ══ DOM helper ═══════════════════════════════════════════
const $ = id => document.getElementById(id);

// ══ Timer ════════════════════════════════════════════════
function fmt(s) {
    const h = Math.floor(s/3600), m = Math.floor((s%3600)/60), ss = s%60;
    return [h,m,ss].map(v => String(v).padStart(2,'0')).join(':');
}

function startTimer() {
    if (timerInterval) return;
    timerInterval = setInterval(() => {
        if (isPaused) return;
        elapsedSeconds++;
        const f = fmt(elapsedSeconds);
        $('timer-val').textContent       = f;
        $('s-timer').textContent         = '⏱ ' + f;
        $('pause-timer-big').textContent = f;
        if (elapsedSeconds % 5 === 0) persistTimer();
    }, 1000);
}

function stopTimer() {
    clearInterval(timerInterval);
    timerInterval = null;
    persistTimer();
}

function persistTimer() {
    if (!savedProgress) return;
    savedProgress.elapsedSeconds = elapsedSeconds;
    localStorage.setItem(SAVE_KEY, JSON.stringify(savedProgress));
}

// ══ Pause ════════════════════════════════════════════════
function togglePause() {
    isPaused = !isPaused;
    const btn = $('btn-pause-top');
    const box = $('timer-box');
    if (isPaused) {
        $('pause-overlay').classList.add('active');
        btn.textContent = '▶'; btn.classList.add('paused');
        box.classList.add('paused');
        persistTimer();
    } else {
        $('pause-overlay').classList.remove('active');
        btn.textContent = '⏸'; btn.classList.remove('paused');
        box.classList.remove('paused');
    }
}

// ══ Reset ════════════════════════════════════════════════
function resetQuiz() {
    if (!confirm('Effacer toute la progression et recommencer ?')) return;
    stopTimer();
    localStorage.removeItem(SAVE_KEY);
    location.href = location.href.split('?')[0] + '?t=' + Date.now();
}

// ══ Retry failed ═════════════════════════════════════════
function retryFailed() {
    const failed = questions.filter((_, i) => answers[i] && !answers[i].correct);
    if (!failed.length) return;
    stopTimer();
    const seed = Math.floor(Math.random() * 2**32);
    const shuffled = seededShuffle(failed, seed);
    localStorage.setItem(SAVE_KEY, JSON.stringify({
        seed, isRetryMode: true,
        retryQuestions: shuffled,
        questionIds: shuffled.map(q => q.id ?? (q.text||q.question)),
        answers: {}, flagged: {}, currentIdx: 0,
        elapsedSeconds: 0, sessionIdx: 0, sessionHistory: []
    }));
    location.href = location.href.split('?')[0] + '?t=' + Date.now();
}

// ══ Next session ═════════════════════════════════════════
function nextSession() {
    $('final-overlay').classList.remove('active');
    sessionIdx++;
    if (sessionIdx >= sessions.length) return;

    questions      = sessions[sessionIdx];
    answers        = {};
    flagged        = {};
    currentIdx     = 0;
    elapsedSeconds = 0;

    const f = fmt(0);
    $('timer-val').textContent       = f;
    $('s-timer').textContent         = '⏱ ' + f;
    $('pause-timer-big').textContent = f;

    savedProgress.sessionIdx     = sessionIdx;
    savedProgress.answers        = answers;
    savedProgress.flagged        = flagged;
    savedProgress.currentIdx     = 0;
    savedProgress.elapsedSeconds = 0;
    savedProgress.sessionHistory = sessionHistory;
    localStorage.setItem(SAVE_KEY, JSON.stringify(savedProgress));

    updateReviewGrid();
    renderQuestion(0);
    updateGlobalProgress();
    startTimer();
}

// ══ Review toggle ═════════════════════════════════════════
function toggleReview() {
    const p = $('review-panel');
    p.style.display = p.style.display === 'none' ? '' : 'none';
}

// ══ Flag ═════════════════════════════════════════════════
function toggleFlag() {
    flagged[currentIdx] = !flagged[currentIdx];
    updateFlagBtn();
    updateReviewGrid();
    saveAll();
}

function updateFlagBtn() {
    const btn = $('qcard-flag');
    if (flagged[currentIdx]) {
        btn.textContent = '⚑ Marqué'; btn.classList.add('active');
    } else {
        btn.textContent = '⚑ Marquer'; btn.classList.remove('active');
    }
}

// ══ Shuffle / sessions ═══════════════════════════════════
function seededShuffle(arr, seed) {
    let s = seed >>> 0;
    function rand() {
        s += 0x6D2B79F5;
        let t = Math.imul(s ^ s>>>15, 1|s);
        t ^= t + Math.imul(t ^ t>>>7, 61|t);
        return ((t ^ t>>>14) >>> 0) / 4294967296;
    }
    const out = arr.slice();
    for (let i = out.length-1; i > 0; i--) {
        const j = Math.floor(rand()*(i+1));
        [out[i], out[j]] = [out[j], out[i]];
    }
    return out;
}

function buildSessions(pool, seed) {
    const shuffled = seededShuffle(pool, seed);
    const result = [];
    for (let i = 0; i < shuffled.length; i += SESSION_SIZE)
        result.push(shuffled.slice(i, i + SESSION_SIZE));
    return result;
}

function parseCorrect(c) {
    if (Array.isArray(c)) return c.map(String);
    if (typeof c === 'string') return c.length > 1 ? c.split('') : [c];
    return [];
}

// ══ Scoreboard (session) ══════════════════════════════════
function updateScoreboard() {
    const total   = questions.length;
    const correct = Object.values(answers).filter(a => a.correct).length;
    const wrong   = Object.keys(answers).length - correct;

    $('s-cur').textContent  = currentIdx + 1;
    $('s-tot').textContent  = total;
    $('s-ok').textContent   = correct;
    $('s-bad').textContent  = wrong;
    $('prog-fill').style.width = (Object.keys(answers).length / total * 100) + '%';

    if (!isRetryMode) {
        $('session-label').textContent = `Session ${sessionIdx+1} / ${sessions.length}`;
    } else {
        $('session-label').textContent = 'Révision';
    }
}

// ══ Global progress bar (all 637) ════════════════════════
function updateGlobalProgress() {
    if (isRetryMode) return;
    const totalQ    = allQuestions.length;
    const doneQ     = sessions.slice(0, sessionIdx).reduce((s,a) => s + a.length, 0)
                    + Object.keys(answers).length;
    const pct = Math.round(doneQ / totalQ * 100);

    const globalCorrect = sessionHistory.filter(Boolean).reduce((s,h) => s + h.correct, 0)
                        + Object.values(answers).filter(a => a.correct).length;

    $('global-fill').style.width  = pct + '%';
    $('global-pct').textContent   = pct + '%';
    $('global-score').textContent = globalCorrect + '/' + totalQ;
}

// ══ Render question ═══════════════════════════════════════
function renderQuestion(idx) {
    const q          = questions[idx];
    const correctArr = parseCorrect(q.correctAnswer);
    const isMulti    = correctArr.length > 1;
    const saved      = answers[idx];
    const total      = questions.length;

    $('qcard-num').textContent = `QUESTION ${idx+1} / ${total}`;
    // hide header badge — we'll show inline under question text
    $('choose-badge').classList.remove('visible');

    $('question-text').textContent = q.text || q.question || '';
    updateFlagBtn();

    const container = $('options-container');
    container.innerHTML = '';
    const selSet = new Set(saved ? saved.selected : []);

    // ── "Choisir X" inline label under question ──
    if (isMulti) {
        const wordsFr = ['','une','deux','trois','quatre','cinq'];
        const n = correctArr.length;
        const word = wordsFr[n] || n;
        const chooseLbl = document.createElement('div');
        chooseLbl.className = 'choose-inline';
        chooseLbl.textContent = `☑ Choisir ${word} réponse${n > 1 ? 's' : ''}`;
        container.appendChild(chooseLbl);
    }

    const qId = `q_${idx}`;

    (q.options || []).forEach(opt => {
        const val  = opt.value || opt.text || '';
        const text = opt.text  || opt.value || '';
        const inputId = `${qId}_${val}`;

        const row  = document.createElement('div');
        row.className   = 'opt-row';
        row.dataset.val = val;
        if (selSet.has(val)) row.classList.add('selected');

        if (saved) {
            row.classList.add('locked');
            const isSel = selSet.has(val);
            const isC   = correctArr.includes(val);
            if      (isSel &&  isC) row.classList.add('opt-correct');
            else if (isSel && !isC) row.classList.add('opt-wrong');
            else if (!isSel && isC) row.classList.add('opt-missed');
        }

        // Real checkbox or radio
        const input = document.createElement('input');
        input.type    = isMulti ? 'checkbox' : 'radio';
        input.name    = qId;
        input.value   = val;
        input.id      = inputId;
        input.checked = selSet.has(val);
        input.disabled = !!saved;
        input.className = 'opt-input';

        const lbl = document.createElement('label');
        lbl.htmlFor   = inputId;
        lbl.className = 'opt-text';
        lbl.textContent = `${val}. ${text}`;

        row.appendChild(input);
        row.appendChild(lbl);

        if (!saved) {
            row.addEventListener('click', e => {
                if (e.target === input) return; // let native handle it
                if (isMulti) {
                    input.checked = !input.checked;
                } else {
                    container.querySelectorAll('.opt-input').forEach(i => i.checked = false);
                    input.checked = true;
                }
                // sync .selected class
                container.querySelectorAll('.opt-row').forEach(r => {
                    const inp = r.querySelector('.opt-input');
                    r.classList.toggle('selected', inp && inp.checked);
                });
            });
            input.addEventListener('change', () => {
                if (!isMulti) {
                    container.querySelectorAll('.opt-row').forEach(r => {
                        const inp = r.querySelector('.opt-input');
                        r.classList.toggle('selected', inp && inp.checked);
                    });
                } else {
                    row.classList.toggle('selected', input.checked);
                }
            });
        }

        container.appendChild(row);
    });

    const strip = $('result-strip');
    if (saved) {
        strip.style.display = 'block';
        strip.className     = saved.correct ? 'correct' : 'wrong';
        strip.textContent   = saved.correct
            ? '✓ Bonne réponse !'
            : '✗ Mauvaise réponse — les bonnes réponses sont indiquées en vert.';
        $('btn-submit').disabled    = false;
        $('btn-submit').textContent = 'Modifier';
    } else {
        strip.style.display  = 'none';
        $('btn-submit').disabled    = false;
        $('btn-submit').textContent = 'Valider';
    }

    $('btn-prev').disabled   = idx === 0;
    $('btn-next-q').disabled = idx === questions.length - 1;
    $('bnav-prev').disabled  = idx === 0;
    $('bnav-next').disabled  = idx === questions.length - 1;

    updateScoreboard();
    updateGlobalProgress();
    updateReviewGrid();
    $('question-card').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ══ Submit answer ════════════════════════════════════════
function submitAnswer() {
    if (answers[currentIdx] && $('btn-submit').textContent === 'Modifier') {
        delete answers[currentIdx];
        renderQuestion(currentIdx);
        return;
    }

    const container  = $('options-container');
    const q          = questions[currentIdx];
    const correctArr = parseCorrect(q.correctAnswer);
    const selected   = Array.from(container.querySelectorAll('.opt-input:checked'))
                           .map(i => i.value);
    if (!selected.length) return;

    const allCorrect = correctArr.every(c => selected.includes(c)) &&
                       selected.every(s => correctArr.includes(s));

    answers[currentIdx] = { selected, correct: allCorrect };
    saveAll();
    renderQuestion(currentIdx);

    const answeredCount = Object.keys(answers).length;

    if (answeredCount === questions.length) {
        setTimeout(showSessionEnd, 700);
    } else if (allCorrect) {
        setTimeout(() => {
            const next = findNextUnanswered(currentIdx);
            if (next !== null) { currentIdx = next; renderQuestion(currentIdx); }
        }, 500);
    }
}

function findNextUnanswered(from) {
    for (let i = from+1; i < questions.length; i++) if (!answers[i]) return i;
    for (let i = 0; i < from; i++)                  if (!answers[i]) return i;
    return null;
}

// ══ Navigate ════════════════════════════════════════════
function navigate(dir) {
    const next = currentIdx + dir;
    if (next < 0 || next >= questions.length) return;
    currentIdx = next;
    renderQuestion(currentIdx);
}

// ══ Review grid ══════════════════════════════════════════
function updateReviewGrid() {
    const grid = $('review-grid');
    grid.innerHTML = '';
    questions.forEach((_, i) => {
        const btn = document.createElement('button');
        btn.className   = 'rev-btn';
        btn.textContent = i + 1;
        if (i === currentIdx)   btn.classList.add('current');
        else if (answers[i])    btn.classList.add(answers[i].correct ? 'ok' : 'bad');
        if (flagged[i])         btn.classList.add('flagged');
        btn.addEventListener('click', () => { currentIdx = i; renderQuestion(i); });
        grid.appendChild(btn);
    });
}

// ══ Session end modal ══════════════════════════════════════
function showSessionEnd() {
    stopTimer();

    const total   = questions.length;
    const correct = Object.values(answers).filter(a => a.correct).length;
    const wrong   = total - correct;
    const pct     = Math.round(correct / total * 100);
    const passed  = correct >= Math.min(PASS_THRESHOLD, total); // handles last session < 120

    // Store in history
    sessionHistory[sessionIdx] = { correct, total, elapsed: elapsedSeconds };
    saveAll();

    const isLastSession = isRetryMode || sessionIdx >= sessions.length - 1;

    $('final-icon-big').textContent  = passed ? '🎉' : '📚';
    $('final-title').textContent     = isRetryMode ? 'Révision terminée' : `Session ${sessionIdx+1} / ${sessions.length} terminée`;
    $('final-subtitle').textContent  = `Temps : ${fmt(elapsedSeconds)}`;
    $('f-correct').textContent       = correct;
    $('f-wrong').textContent         = wrong;
    $('f-pct').textContent           = pct + '%';

    const msgBox = $('final-msg-box');
    if (passed) {
        msgBox.className   = 'pass';
        msgBox.textContent = correct === total
            ? '✅ Score parfait !'
            : `✅ Réussi — ${correct}/${total} (seuil de 75 atteint)`;
    } else {
        const manque = Math.min(PASS_THRESHOLD, total) - correct;
        msgBox.className   = 'fail';
        msgBox.textContent = `❌ Il manque ${manque} bonne${manque>1?'s':''} réponse${manque>1?'s':''} pour atteindre 75/${total}.`;
    }

    // Session history table
    const histDiv = $('session-history');
    histDiv.innerHTML = '';
    const histData = sessionHistory.filter(Boolean);
    if (histData.length > 1) {
        const wrap = document.createElement('div');
        wrap.style.cssText = 'text-align:left;font-size:.78rem';
        const title = document.createElement('div');
        title.style.cssText = 'font-weight:700;color:var(--text);margin-bottom:6px';
        title.textContent = 'Historique des sessions';
        wrap.appendChild(title);
        histData.forEach((h, i) => {
            const p   = Math.round(h.correct/h.total*100);
            const ok  = h.correct >= Math.min(PASS_THRESHOLD, h.total);
            const row = document.createElement('div');
            row.style.cssText = 'display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--border2)';
            row.innerHTML = `<span style="color:var(--gray)">Session ${i+1} (${h.total} q)</span>
                             <span style="font-family:'IBM Plex Mono',monospace;font-weight:700;color:${ok?'var(--green)':'var(--red)'}">
                               ${h.correct}/${h.total} — ${fmt(h.elapsed)}
                             </span>`;
            wrap.appendChild(row);
        });
        histDiv.appendChild(wrap);
    }

    // Global summary (last session only)
    const globalDiv = $('global-summary');
    if (isLastSession && !isRetryMode) {
        const totalCorrect = histData.reduce((s,h) => s+h.correct, 0);
        const totalAll     = allQuestions.length;
        const totalTime    = histData.reduce((s,h) => s+h.elapsed, 0);
        const gpct         = Math.round(totalCorrect/totalAll*100);
        globalDiv.style.display = 'block';
        globalDiv.innerHTML = `
            <div style="padding:14px 16px;background:var(--blue-lt);border:1px solid var(--blue);border-radius:10px;text-align:center;margin-top:4px">
                <div style="font-size:.72rem;color:var(--blue);font-weight:700;letter-spacing:.06em;margin-bottom:6px">SCORE GLOBAL — ${totalAll} QUESTIONS</div>
                <div style="font-size:1.8rem;font-weight:800;font-family:'IBM Plex Mono',monospace;color:var(--blue)">${totalCorrect}/${totalAll} (${gpct}%)</div>
                <div style="font-size:.78rem;color:var(--gray);margin-top:4px">Temps total : ${fmt(totalTime)}</div>
            </div>`;
    } else {
        globalDiv.style.display = 'none';
    }

    // Buttons
    const nextBtn  = $('btn-next-session');
    const retryBtn = $('btn-retry-failed');

    nextBtn.style.display  = (!isRetryMode && !isLastSession) ? 'block' : 'none';
    if (!isRetryMode && !isLastSession) {
        nextBtn.textContent = `▶ Session ${sessionIdx+2} / ${sessions.length} (${sessions[sessionIdx+1].length} questions)`;
    }

    retryBtn.style.display  = wrong > 0 ? 'block' : 'none';
    if (wrong > 0) retryBtn.textContent = `🔁 Revoir les ${wrong} erreur${wrong>1?'s':''}`;

    $('final-overlay').classList.add('active');
}

// ══ Persistence ══════════════════════════════════════════
function saveAll() {
    if (!savedProgress) return;
    savedProgress.answers        = answers;
    savedProgress.flagged        = flagged;
    savedProgress.currentIdx     = currentIdx;
    savedProgress.elapsedSeconds = elapsedSeconds;
    savedProgress.sessionIdx     = sessionIdx;
    savedProgress.sessionHistory = sessionHistory;
    localStorage.setItem(SAVE_KEY, JSON.stringify(savedProgress));
}

function loadSaved() {
    try { const r = localStorage.getItem(SAVE_KEY); return r ? JSON.parse(r) : null; }
    catch { return null; }
}

// ══ Init ═════════════════════════════════════════════════
function loadQuestions() {
    savedProgress = loadSaved();

    if (savedProgress?.isRetryMode && savedProgress?.retryQuestions) {
        isRetryMode  = true;
        sessions     = [savedProgress.retryQuestions];
        allQuestions = savedProgress.retryQuestions;
        $('retry-banner').style.display = 'block';
        $('global-bar').style.display   = 'none';
    } else {
        allQuestions = data.questions; // all 637
        let seed = savedProgress?.seed ?? Math.floor(Math.random() * 2**32);
        sessions = buildSessions(allQuestions, seed);

        if (!savedProgress) {
            savedProgress = {
                seed, answers: {}, flagged: {}, currentIdx: 0,
                elapsedSeconds: 0, sessionIdx: 0, sessionHistory: []
            };
            localStorage.setItem(SAVE_KEY, JSON.stringify(savedProgress));
        } else {
            // Use saved seed to guarantee same session order
            if (savedProgress.seed && savedProgress.seed !== seed) {
                sessions = buildSessions(allQuestions, savedProgress.seed);
            }
        }
    }

    sessionHistory = savedProgress.sessionHistory || [];
    sessionIdx     = Math.min(savedProgress.sessionIdx || 0, sessions.length - 1);
    questions      = sessions[sessionIdx];
    answers        = savedProgress.answers     || {};
    flagged        = savedProgress.flagged     || {};
    currentIdx     = Math.min(savedProgress.currentIdx || 0, questions.length - 1);
    elapsedSeconds = savedProgress.elapsedSeconds || 0;

    const f = fmt(elapsedSeconds);
    $('timer-val').textContent       = f;
    $('s-timer').textContent         = '⏱ ' + f;
    $('pause-timer-big').textContent = f;

    updateReviewGrid();
    renderQuestion(currentIdx);
    updateGlobalProgress();

    if (Object.keys(answers).length >= questions.length) {
        showSessionEnd();
    } else {
        startTimer();
    }
}

// Auto-pause on tab switch
document.addEventListener('visibilitychange', () => {
    if (document.hidden && !isPaused) togglePause();
});

// Keyboard shortcuts
document.addEventListener('keydown', e => {
    if ($('pause-overlay').classList.contains('active')) return;
    if ($('final-overlay').classList.contains('active')) return;
    if (e.key === 'ArrowRight') navigate(1);
    if (e.key === 'ArrowLeft')  navigate(-1);
    if (e.key === 'Enter') submitAnswer();
});

window.addEventListener('DOMContentLoaded', loadQuestions);
