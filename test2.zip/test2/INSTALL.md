# 📱 Guide d'installation — AML Quiz PWA

## Structure des fichiers à respecter

```
aml-quiz/               ← dossier racine de ton serveur web
├── index.html
├── manifest.json
├── sw.js
├── icons/
│   ├── icon-72x72.png
│   ├── icon-96x96.png
│   ├── icon-128x128.png
│   ├── icon-144x144.png
│   ├── icon-152x152.png
│   ├── icon-192x192.png
│   ├── icon-384x384.png
│   └── icon-512x512.png
└── js/
    ├── data.js
    └── index.js
```

---

## ⚠️ Prérequis obligatoire : HTTPS

La PWA **nécessite HTTPS** pour fonctionner (le Service Worker ne marche pas en HTTP simple).  
Options gratuites recommandées :

| Service | Gratuit | Domaine |
|---------|---------|---------|
| **GitHub Pages** | ✅ | `ton-nom.github.io/aml-quiz` |
| **Netlify** | ✅ | `aml-quiz.netlify.app` |
| **Vercel** | ✅ | `aml-quiz.vercel.app` |

---

## 🚀 Option 1 — GitHub Pages (recommandé)

1. Crée un compte sur [github.com](https://github.com)
2. Crée un nouveau repository public → nomme-le `aml-quiz`
3. Upload tous les fichiers (respecte la structure ci-dessus)
4. Va dans **Settings → Pages → Source → main branch → Save**
5. Ton quiz sera accessible sur `https://TON-NOM.github.io/aml-quiz/`

---

## 🚀 Option 2 — Netlify (drag & drop, le plus simple)

1. Va sur [netlify.com](https://netlify.com) → crée un compte gratuit
2. Dashboard → **"Add new site" → "Deploy manually"**
3. Glisse-dépose le **dossier** `aml-quiz/` entier dans la zone
4. C'est tout ! Netlify génère une URL HTTPS automatiquement

---

## 📲 Installer l'app sur Android

Une fois le site en ligne sur HTTPS :

1. Ouvre **Chrome** sur ton Android
2. Va sur l'URL de ton quiz
3. Attends 2–3 secondes que la page charge complètement
4. Chrome affiche une bannière **"Ajouter à l'écran d'accueil"** → tape dessus  
   *(Si la bannière n'apparaît pas : menu ⋮ → "Ajouter à l'écran d'accueil")*
5. Confirme → l'icône **AML Quiz** apparaît sur ton écran d'accueil
6. Lance l'app → elle s'ouvre en plein écran, sans barre Chrome ✅

---

## ✅ Fonctionnalités offline

Après la première visite, le Service Worker met tout en cache.  
**Le quiz fonctionne sans internet** (questions, timer, sauvegarde — tout local).

---

## 🧪 Test local (sans serveur)

Pour tester en local avant de déployer :

```bash
# Python (si installé)
cd aml-quiz/
python3 -m http.server 8080
# Ouvre http://localhost:8080
```

> ⚠️ Le Service Worker ne s'active qu'en HTTPS ou sur `localhost`.
